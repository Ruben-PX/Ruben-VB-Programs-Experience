﻿Public Class Main
    Public Name As String = "Raiz Cuadrada"
    Public Type As Integer = 1
    Public Function Make(N1 As Decimal, N2 As Decimal)
        Return Math.Sqrt(N1)
    End Function
End Class
