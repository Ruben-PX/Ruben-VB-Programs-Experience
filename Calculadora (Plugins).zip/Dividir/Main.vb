﻿Public Class Main
    Public Name As String = "Dividir"
    Public Type As Integer = 2
    Public Function Make(N1 As Decimal, N2 As Decimal)
        Return N1 / N2
    End Function
End Class
